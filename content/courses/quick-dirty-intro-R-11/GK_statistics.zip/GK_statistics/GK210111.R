# HOW? the ABC

# How to execute commands to the R prompt:
	
	# "Mac-key" + enter for MAC
	# CTRL + enter for windows
	# linux: copy & paste

# What if I want to know what a command does?

help(anova)
?anova

# a little math
2+2
2/2

# variable storage
newvar1 = 2*2
newvar1
newvar1 - 3

# data formats: character vs. numeric
newvar1 = as.character(newvar1)
newvar1 - 3
newvar1 = as.numeric(newvar1)
newvar1 - 3

# data formats: vector
newnumvector = c(4,5,6,2,3,5,8,13,21,34,55)
newnumvector
log(newnumvector)
newcatvector = c("di", "a", "da", "in", "con", "su", "per", "tra", "fra")
newcatvector

# data formats: dataset

# let's import a dataset from a txt file
# MAC
heid = read.table("/Users/alessandra/Desktop/Stat_GS/heid.txt",header=TRUE)
# Linux
heid = read.table("/home/users0/zarconaa/Desktop/Stat_GS/heid.txt",header=TRUE)
# Win
heid = read.table("c:/Documents/Stat_GS/heid.txt",header=TRUE)

# a first look at the dataset
head(heid)

# HOW? descriptive statistics

# the id card of the data
summary(heid)

# minimum RT value
min(heid$RT)
# maximum RT value
max(heid$RT)
# mean RT value
mean(heid$RT)
# median RT value
median(heid$RT)

# an histogram (continuous variable)
hist(heid$RT)

# let's import a dataset from a file
# MAC
amt = read.csv("/Users/alessandra/Desktop/Stat_GS/amt.csv",sep=",",header=TRUE)
# Linux
amt = read.csv("/home/users0/zarconaa/Desktop/Stat_GS/amt.csv",sep=",",header=TRUE)
# Win
amt = read.csv("c:/Documents/Stat_GS/amt.csv",sep=",",header=TRUE)

head(amt)
summary(amt)

# levels of factor "Cat"
levels(amt$Cat)

# a contingency table
xtabs(~ Cat  + Rank, data = amt)

# an histogram (continuous variable)
hist(amt$Rank)

# a box-and-whiskers plot
boxplot(Rank~Cat,data=amt, main="Acceptability of paraphrases", xlab="Type of sentence", ylab="Acceptability")

# a barplot
meansperlevel <- tapply((amt$Rank), amt$Cat, mean)
barplot(meansperlevel, col=c("pink","blue","green"))

# HOW? inferential statistics

# MAC
ratings = read.table("/Users/alessandra/Desktop/Stat_GS/ratings.txt",header=TRUE)
# Linux
ratings = read.table("/home/users0/zarconaa/Desktop/Stat_GS/ratings.txt",header=TRUE)
# Win
ratings = read.table("c:/Documents/Stat_GS/ratings.txt",header=TRUE)

# correlation
cor(ratings$meanWeightRating,ratings$meanSizeRating)


# one sample t-test

t.test(heid$RT,mu = 6.7)

# two sample t-test
t.test(ratings$meanWeightRating,ratings$meanSizeRating)

# two sample paired t-test
t.test(ratings$meanWeightRating,ratings$meanSizeRating,paired=T)

# linear regression model

mod.lm1 = lm(ratings$meanWeightRating~ratings$meanSizeRating)
anova(mod.lm1)

mod.lm2 = lm(heid$RT~heid$BaseFrequency)
anova(mod.lm2)

mod.lm3 = lm(amt$Rank~amt$Cat)
anova(mod.lm3)
summary(mod.lm3)

# multilinear regression model

mod.lm4 = lm(ratings$meanWeightRating ~ ratings$Class + ratings$meanSizeRating)
anova(mod.lm4)
summary(mod.lm4)